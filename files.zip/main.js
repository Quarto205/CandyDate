document.addEventListener('DOMContentLoaded', () => {
  // loader
  const loader = document.getElementById('loader');
  const progressText = document.getElementById('loader-progress');
  if (loader && progressText) {
    let progress = 0;
    const tick = () => {
      progress += Math.floor(Math.random()*10)+4;
      if (progress > 100) progress = 100;
      progressText.textContent = String(progress).padStart(2,'0');
      if (progress < 100) {
        setTimeout(tick, 90);
      } else {
        setTimeout(() => {
          loader.classList.add('hidden');
          document.body.classList.add('loaded');
        }, 200);
      }
    };
    tick();
  } else {
    document.body.classList.add('loaded');
  }

  // custom cursor
  const cursor = document.getElementById('cursor');
  if (cursor) {
    window.addEventListener('mousemove', (e) => {
      cursor.style.left = e.clientX + 'px';
      cursor.style.top = e.clientY + 'px';
    });
    document.querySelectorAll('.hover-target').forEach(el => {
      el.addEventListener('mouseenter', () => cursor.classList.add('hover-state'));
      el.addEventListener('mouseleave', () => cursor.classList.remove('hover-state'));
    });
  }

  // about panel (present on any page that includes it)
  const panel = document.getElementById('about-panel');
  const toggle = document.getElementById('about-toggle');
  const closeBtn = document.getElementById('close-about');
  if (panel && toggle) {
    toggle.addEventListener('click', () => panel.classList.add('active'));
    if (closeBtn) closeBtn.addEventListener('click', () => panel.classList.remove('active'));
    panel.addEventListener('click', (e) => { if (e.target === panel) panel.classList.remove('active'); });
    window.addEventListener('keydown', (e) => { if (e.key === 'Escape') panel.classList.remove('active'); });
    if (window.location.hash === '#about') panel.classList.add('active');
  }
});
